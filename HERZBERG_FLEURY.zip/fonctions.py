"""
Fichier: fonctions.py
Auteur: Dwayne HERZBERG, Nathan FLEURY
description:
    Ce fichier contient les fonctions utilisées par le programme.
"""

from copy import deepcopy
from classes import Rumba


def heuristique(init: Rumba, g: int, but: Rumba):
    """
    Fonction qui calcule l'heuristique de l'état init en fonction de l'état but.
    """
    if not isinstance(init, Rumba):
        raise TypeError(f"init must be of type {Rumba}")
    if not isinstance(but, init.__class__):
        raise TypeError(f"but must be of type {init.__class__}")
    if not isinstance(g, int):
        raise TypeError(f"g must be of type int")
    h = init.nombreMalMis(but)
    return g + h


def opPoss(init: Rumba) -> list:
    """
    Fonction qui prend en paramètre un état de type Rumba et renvoi une liste de tuple de la forme (opération, nouvel état, coût).
    Pour chaque état de la liste de tuple, la valeur de la variable operation est une chaîne de caractère indiquant l'opération
    qui a été effectuée pour passer de l'état init à cet état, nouvel_etat est l'état résultant de l'opération et coût est le coût
    de l'opération.
    """
    if not isinstance(init, Rumba):
        raise TypeError(f"init must be of type {Rumba}")
    operations = []
    for i, tige_depart in enumerate(init.tiges):
        for j, tige_arrivee in enumerate(init.tiges):
            if i != j and not tige_depart.est_vide() and not tige_arrivee.est_pleine():
                nouvel_etat = deepcopy(init)
                nouvel_etat.deplacer(i, j)
                operation = f"Deplacer {tige_depart.head()} de Tige {i+1} à Tige {j+1}"
                operations.append((operation, nouvel_etat, 1))
    return operations


def estBut(init: Rumba, but: Rumba) -> bool:
    if not isinstance(init, Rumba):
        raise TypeError(f"init must be of type {Rumba}")
    if not isinstance(but, init.__class__):
        raise TypeError(f"but must be of type {init.__class__}")
    return init == but

# Fonction IDA * {retourne un état-solution ou échec}
#   Arguments
#       départ; {l'état initial}
#       testEtatBut; {prédicat caractérisant les buts}
#       filsEtat; {retourne la liste des fils d'un état}
#       fEtat; {estime la promesse d'un état, i.e. l'intérêt d'exploiter l'état, voir le rappel ci-après}
#   Variables locales à la fonction IDA*
#       seuil; {valeur à ne pas dépasser dans une itération}
#       terminé; {booléen}
#       solution; {état}
# Début
#   solution < - nul;
#   seuil < - fEtat(départ);
#   Répéter terminé < - ProfondeurBornée(seuil); Jusqu’à terminé;
#   Si solution ≠ nul Alors retourner(solution); Sinon retourner(échec); FinSi;
# Fin
