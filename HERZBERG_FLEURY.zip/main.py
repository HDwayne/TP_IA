"""
Fichier: main.py
Auteur: Dwayne HERZBERG, Nathan FLEURY
description:
    Ce fichier contient le code principal du programme.
"""

from fonctions import *
from test import *


si = situation_initiale_1()
but5 = but_5()

# afficher

si.afficherEtat()
but5.afficherEtat()

# heuristique

print(heuristique(si, 0, but5))
print(heuristique(si, 0, si))

# opPoss

for op, init, n in opPoss(si):
    print(op)

# estBut

print(estBut(si, but5))
print(estBut(but5, but5))

# Fonction IDA * {retourne un état-solution ou échec}
